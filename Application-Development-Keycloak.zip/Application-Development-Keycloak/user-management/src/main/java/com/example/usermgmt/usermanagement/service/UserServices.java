package com.example.usermgmt.usermanagement.service;
import com.example.usermgmt.usermanagement.datatransferobjects.AuthenticateDTO;
import com.example.usermgmt.usermanagement.datatransferobjects.AuthenticateRequestDTO;
import com.example.usermgmt.usermanagement.datatransferobjects.UserDTO;
import com.example.usermgmt.usermanagement.entities.UzmUsersEntity;
import com.example.usermgmt.usermanagement.repositories.IUsersRepository;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.modelmapper.spi.MatchingStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServices {

    private static final org.slf4j.Logger Logger = LoggerFactory.getLogger(UserServices.class);

    @Autowired
    IUsersRepository usersRepository;

    @Autowired
    private ModelMapper modelMapper;

    public UserDTO addUser(UserDTO userDTO){
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STANDARD);
        UzmUsersEntity usersEntity = usersRepository.saveAndFlush(modelMapper.map(userDTO, UzmUsersEntity.class));
        return modelMapper.map(usersEntity, UserDTO.class);
    }

    public UserDTO getUserDetails(int userId){
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STANDARD).setAmbiguityIgnored(true);
        UzmUsersEntity usersEntity = usersRepository.findById(userId).get();
        return modelMapper.map(usersEntity, UserDTO.class);
    }

    public UserDTO updateUser(UserDTO userDTO){
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STANDARD);
        UzmUsersEntity usersEntity = usersRepository.saveAndFlush(modelMapper.map(userDTO, UzmUsersEntity.class));
        return modelMapper.map(usersEntity, UserDTO.class);
    }

    public Boolean removeUser(int userId){
        usersRepository.deleteById(userId);
        return Boolean.TRUE;
    }

    public AuthenticateDTO verifyUser(AuthenticateRequestDTO authenticateRequestDTO)
    {
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STANDARD);
        UzmUsersEntity usersEntity = usersRepository.verifyUser(authenticateRequestDTO.getUserEmailId(),authenticateRequestDTO.getPassword());
        return modelMapper.map(usersEntity,AuthenticateDTO.class);
    }

    public List<AuthenticateDTO> searchUsersByCreationDate(Date date)
    {
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STANDARD);
        List<UzmUsersEntity> listUsersEntity = usersRepository.findAllByCreationDate(date);
        return listUsersEntity.stream().map(users -> modelMapper.map(users,AuthenticateDTO.class)).collect(Collectors.toList());
    }
}
