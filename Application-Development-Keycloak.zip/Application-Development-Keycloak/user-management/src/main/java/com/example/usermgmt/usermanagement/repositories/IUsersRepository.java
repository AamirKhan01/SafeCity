package com.example.usermgmt.usermanagement.repositories;

import com.example.usermgmt.usermanagement.entities.UzmUsersEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.sql.Date;
import java.util.List;

public interface IUsersRepository extends JpaRepository<UzmUsersEntity, Integer> {

    @Query("FROM UzmUsersEntity WHERE userEmailId=?1 AND password=?2")
    UzmUsersEntity verifyUser(String email, String password);
    List<UzmUsersEntity> findAllByCreationDate(Date date);
}