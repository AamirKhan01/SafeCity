//package com.example.usermgmt.usermanagement.datatransferobjects;
//
//public class UserGroupDTO {
//}
